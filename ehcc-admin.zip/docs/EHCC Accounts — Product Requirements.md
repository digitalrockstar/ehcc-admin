# EHCC Accounts

## 1. Product Overview

**EHCC Accounts** is a web application for managing a cricket team's matches, player participation, match fees, collections, team expenses, player receivables, player payables, reimbursements, additional income, and the overall team account.

The application must maintain a clear distinction between:

- **Money the Team has**
- **Money Players owe the Team**
- **Money the Team owes Players**
- **Additional Income / Surplus**

Every financial event must be traceable from its origin to its final settlement.

### Technology

- Backend: **Python**
- Database: **Neon PostgreSQL**
- Hosting: **Render**
- Responsive web application
- Production-ready environment configuration
- Secure secrets/configuration
- Database migrations
- Clean separation between business logic and UI
- API-driven architecture where appropriate

---

# 2. Core Financial Concepts

The application has three primary financial positions plus additional income.

### Team account

Actual cash currently available to the team.

### Player Receivables

Money that players owe the team.

Example:

> Rahul owes the team ₹450 for a match fee.

### Player Payables

Money that the team owes players.

Example:

> Akshay personally bought cricket balls for ₹470, so the team owes Akshay ₹470.

### Additional Income / Surplus

Money received by the team that is not required to settle an existing player fee or receivable.

Examples:

- Match fee collection above total player fee obligations
- Team contribution
- Sponsorship
- Donation
- Miscellaneous income

These amounts increase Team account and are recorded separately as additional income.

Player receivables and player payables must remain separate.

A player can simultaneously:

- owe the team ₹450
- be owed ₹470 by the team

---

# 3. Initial Team Setup

During setup, the administrator can enter:

- Team Name
- Starting Balance

### Example

Starting Balance:

**₹10,000**

Initial position:

| Metric | Amount |
|---|---:|
| Starting Balance | ₹10,000 |
| account | ₹10,000 |
| Players Owe Team | ₹0 |
| Team Owes Players | ₹0 |
| Additional Income | ₹0 |

---

# 4. Player Master

Administrators can add, edit and manage players.

### Fields

- Player Name — required
- Contact Number — optional, exactly 10 digits if entered
- Status — Active / Inactive

Players should not be deleted if they have historical financial records.

Instead, mark them **Inactive**.

### Player View

Each player should have access to:

- Matches played
- Match fees
- Team expense receivables
- Team expenses personally paid
- Reimbursements
- Total owed by player
- Total owed to player
- Net balance

A new player can also be added directly while creating a match.

---

# 5. Match Management

Administrators can create, edit and view matches.

### Match Fields

- Match Date — required
- Match Status:
  - Upcoming
  - Completed
  - Cancelled
- Match Notes — optional
- Participating Players

The player selector should:

- Show active players
- Be searchable
- Use checkboxes
- Show selected-player count
- Allow a new player to be added without leaving the match screen

---

# 6. Match Expenses

Every match has exactly two expense fields:

- **Ground Fees**
- **Additional Amount**

### Formula

**Total Match Expense = Ground Fees + Additional Amount**

### Example

| Expense | Amount |
|---|---:|
| Ground Fees | ₹4,000 |
| Additional Amount | ₹500 |
| **Total Match Expense** | **₹4,500** |

The **Additional Amount** here is an expense, not additional income.

---

# 7. Match Player Fees

The total match expense is divided equally among participating players.

### Formula

**Player Fee = CEILING(Total Match Expense / Number of Participating Players)**

The result must always be rounded **up to the next whole rupee**.

No decimal player fees are allowed.

Every participating player receives the same fee obligation.

### Example 1

Match Expense = ₹4,500  
Players = 10

₹4,500 ÷ 10 = ₹450

Each player owes:

**₹450**

Total player fee obligations:

**₹4,500**

---

### Example 2 — Rounded Player Fee

Match Expense = ₹5,000  
Players = 12

₹5,000 ÷ 12 = ₹416.67

Player Fee:

**₹417**

Total player fee obligations:

**12 × ₹417 = ₹5,004**

Actual match expense:

**₹5,000**

The ₹4 difference is created by the player-fee rounding rule.

It is already included in the players' fee obligations.

It is **not**:

- an additional match expense
- a separate player obligation
- automatically a surplus

If all ₹5,004 of obligations are collected, there is **₹0 match surplus**.

If only ₹5,000 is collected, there is **₹4 outstanding** and **₹0 surplus**.

Only money collected **above the total fee obligations** can become Match Surplus.

---

# 8. Match Fee Receivables

When a match is created, each participating player receives an individual fee obligation.

Each fee has:

- Player
- Match
- Amount
- Status: Due / Paid
- Payment Date

There are **no partial payments against an individual player fee**.

The total of all player fee obligations is the **Total Match Fee Obligations**.

### Example

10 players × ₹450:

| Player | Amount | Status |
|---|---:|---|
| Akshay | ₹450 | Paid |
| Rahul | ₹450 | Paid |
| Amit | ₹450 | Due |
| Ravi | ₹450 | Due |
| ... | ... | ... |
| **Total** | **₹4,500** | |

If 7 players have paid:

- Total Match Fee Obligations: ₹4,500
- Collected: ₹3,150
- Outstanding: ₹1,350

---

# 9. Match Fee Collection

When a player pays their match fee, the system records the actual amount received.

### Normal Example

Rahul owes:

**₹450**

Rahul pays:

**₹450**

The system records:

- Match Fee: ₹450
- Status: Paid
- Payment Date
- Collection: +₹450
- account: +₹450

### Collection Reconciliation

The application must separately track:

- Total Match Fee Obligations
- Total Match Fee Collections
- Fees Settled
- Outstanding Match Fees
- Match Surplus

The system must never create a player fee obligation simply because additional money was collected.

---

# 10. Match Fee Over-Collection / Match Surplus

A match may collect more money than the total player fee obligations.

This excess is **Match Surplus / Additional Income**.

It is not treated as an additional player fee.

### Formula

**Match Surplus = MAX(0, Total Actual Collections − Total Match Fee Obligations)**

### Example

Total Match Fee Obligations:

**₹5,000**

Total Actual Collections:

**₹5,004**

The system records:

- ₹5,000 toward player fee obligations
- ₹4 as Match Surplus / Additional Income

Final:

| Item | Amount |
|---|---:|
| Match Fee Obligations | ₹5,000 |
| Actual Collections | ₹5,004 |
| Fees Settled | ₹5,000 |
| Match Surplus | ₹4 |
| Outstanding Fees | ₹0 |

The full ₹5,004 is an actual cash inflow and therefore increases Team account by ₹5,004.

The ₹4 surplus is only a **classification of part of that collection**. It must not be added to account again.

---

### Under-Collection Example

Total Match Fee Obligations:

**₹5,000**

Total Actual Collections:

**₹4,998**

Result:

| Item | Amount |
|---|---:|
| Fee Obligations | ₹5,000 |
| Actual Collections | ₹4,998 |
| Fees Settled | ₹4,998 |
| Match Surplus | ₹0 |
| Outstanding | ₹2 |

The ₹2 is still owed by players.

It is not surplus.

---

### Exact Collection Example

Total Match Fee Obligations:

**₹5,000**

Total Actual Collections:

**₹5,000**

Result:

- Fees Settled: ₹5,000
- Outstanding: ₹0
- Match Surplus: ₹0

---

### Important Rule

The application must distinguish between:

**Fee Rounding Difference**

and:

**Actual Over-Collection**

For example:

- Match expense: ₹5,000
- 12 players
- Fee per player: ₹417
- Total obligations: ₹5,004

The ₹4 difference between ₹5,000 expense and ₹5,004 obligations is caused by the fee calculation rule.

It becomes **Match Surplus only if actual collections exceed ₹5,004**.

Therefore:

| Actual Collection | Outstanding | Surplus |
|---:|---:|---:|
| ₹5,000 | ₹4 | ₹0 |
| ₹5,004 | ₹0 | ₹0 |
| ₹5,005 | ₹0 | ₹1 |
| ₹5,010 | ₹0 | ₹6 |

---

# 11. Match Surplus / Additional Income Sources

Additional income can originate from:

### Match Surplus

Money actually collected against a match above the total player fee obligations.

Example:

- Player fee obligations: ₹5,004
- Actual collections: ₹5,010
- Match surplus: ₹6

### Ad Hoc Income

Income not directly associated with a player fee.

Examples:

- Team contribution
- Sponsorship
- Donation
- Miscellaneous income

The system should allow additional income to be associated with a match where appropriate, or recorded independently as an **Ad Hoc Income** transaction.

---

# 12. Ad Hoc Income

Provide a dedicated mechanism for recording additional income.

### Fields

- Date
- Income Type
- Amount
- Match — optional
- Notes — optional

Initial income types:

- Team Contribution
- Sponsorship
- Donation
- Miscellaneous Income

Administrators can add additional income categories.

### Example

Team contribution:

**₹2,000**

Effect:

- Additional Income: +₹2,000
- Cash Inflow: +₹2,000
- account: +₹2,000

---

# 13. Team-Level Expenses

Team expenses are separate from matches.

Examples:

- Cricket Balls
- Gloves
- Stumps
- Bats
- Jerseys
- Equipment
- Other Team Expenses

### Fields

- Date
- Expense For / Category
- Amount
- Paid By
- Payment Source
- Reimbursement Status
- Players Responsible for Expense, if applicable

There is no description field.

---

# 14. Expense Categories

Expense For uses a dropdown.

Initial categories:

- Cricket Balls
- Gloves
- Stumps
- Bats
- Jerseys
- Equipment
- Other Team Expenses

Administrators can add new categories.

Once created, a category becomes available for future expenses.

---

# 15. Team Expense Paid from account

If the team pays directly from the account, the expense is immediately a cash expense.

### Example

Cricket Balls:

**₹470**

Paid By:

**Team account**

Effect:

| Item | Effect |
|---|---:|
| Team Expense | +₹470 |
| account | −₹470 |
| Player Payable | ₹0 |
| Player Receivable | ₹0 |

If account was ₹10,000:

**New account = ₹9,530**

No player is owed money.

---

# 16. Team Expense Paid Personally by a Player

A player may personally pay for a team expense.

This creates a **Player Payable**.

### Example

Akshay buys cricket balls for:

**₹470**

Payment Source:

**Player**

Paid By:

**Akshay**

Immediately record:

- Team Expense: ₹470
- Team Owes Akshay: ₹470
- Payable Status: Due
- account: unchanged

### Before reimbursement

| Metric | Amount |
|---|---:|
| account | ₹10,000 |
| Team Expense | ₹470 |
| Team Owes Akshay | ₹470 |

The account does **not** decrease when Akshay buys the balls because team cash has not been spent.

---

# 17. Player Reimbursement

When the team pays a player back:

### Example

Team owes Akshay:

**₹470**

Akshay is reimbursed:

**₹470**

Record:

- Reimbursement Amount: ₹470
- Reimbursement Date
- Player: Akshay
- Status: Paid

Financial effect:

| Item | Effect |
|---|---:|
| Player Payable | ₹470 → ₹0 |
| account | −₹470 |

If account was ₹10,000:

**New account = ₹9,530**

No partial reimbursements are required.

---

# 18. Team Expense Allocated to Players

A team expense may also be assigned to one or more players who are responsible for paying their share.

This creates **Player Receivables**.

All monetary values are whole rupees.

The total allocated player shares must equal the exact expense amount.

### Allocation Formula

For:

- Expense = `E`
- Players = `N`

Calculate:

**Base Share = FLOOR(E / N)**

Then:

**Remainder = E − (Base Share × N)**

Distribute **₹1 at a time** to players in the exact order they were selected for the allocation until the remainder reaches zero.

### Example

Expense:

**₹500**

Players:

**3**

Base Share:

₹166

Remainder:

₹2

Selected order:

1. Player 1 → ₹167
2. Player 2 → ₹167
3. Player 3 → ₹166

Total:

**₹500**

---

### Example

Expense:

**₹470**

Players:

**6**

Base Share:

₹78

Remainder:

₹2

Selected order:

1. Player 1 → ₹79
2. Player 2 → ₹79
3. Player 3 → ₹78
4. Player 4 → ₹78
5. Player 5 → ₹78
6. Player 6 → ₹78

Total:

**₹470**

### Hard Validation

The application must enforce:

**SUM(all player shares) = Expense Amount**

The system must show an allocation preview before saving.

---

# 19. Match Fee Rounding vs Team Expense Allocation

These are intentionally different rules.

### Match Fees

**Player Fee = CEILING(Total Match Expense / Number of Players)**

Every participating player pays the same whole-rupee amount.

The resulting total player fee obligations may be higher than the actual match expense because of rounding.

That difference is part of the player obligations.

It becomes Match Surplus **only when actual collections exceed the total fee obligations**.

### Team Expense Recovery

Use exact allocation.

**SUM(Player Shares) = Expense Amount**

Do not round each player's share independently.

---

# 20. Player Receivable Payment

When a player pays their share:

### Example

Player owes:

**₹94**

Player pays:

**₹94**

Effect:

- Player receivable: Paid
- Cash Collection: +₹94
- account: +₹94
- Remaining receivable decreases

The system must track each player's status independently.

---

# 21. Player Expense Payable and Receivable Can Exist Together

This is an important business rule.

### Example

Akshay buys cricket balls:

**₹470**

Team owes Akshay:

**₹470**

The same expense is allocated to 5 players:

**₹94 each**

Akshay may be one of those players.

Akshay could therefore have:

- Team owes Akshay: ₹470
- Akshay owes team: ₹94

These are separate obligations.

The application must **not automatically offset them**.

Player ledger:

| Transaction | Amount | Direction | Status |
|---|---:|---|---|
| Cricket Balls | ₹470 | Team → Akshay | Due |
| Cricket Balls Share | ₹94 | Akshay → Team | Due |

---

# 22. Player Ledger

Each player should have a consolidated financial ledger.

### Example

| Date | Type | For | Amount | Direction | Status |
|---|---|---|---:|---|---|
| 05 Sep | Match | Match Fee | ₹450 | Player → Team | Paid |
| 10 Sep | Team Expense | Cricket Balls | ₹94 | Player → Team | Due |
| 12 Sep | Team Expense | Gloves | ₹500 | Team → Player | Due |

The player summary should show:

- Total Owed by Player
- Total Owed to Player
- Net Balance

### Example

Player owes team:

₹94

Team owes player:

₹500

Net:

**Team owes player ₹406**

However, the underlying ₹94 receivable and ₹500 payable must remain separately recorded.

---

# 23. Multiple Personal Team Expenses by One Player

### Example

Akshay personally pays:

| Expense | Amount |
|---|---:|
| Cricket Balls | ₹470 |
| Gloves | ₹1,200 |
| Stumps | ₹850 |
| **Total** | **₹2,520** |

Player Payable:

**Team owes Akshay ₹2,520**

The reimbursement screen should show this outstanding balance.

---

# 24. Reimbursements

A reimbursement screen should allow the administrator to:

1. Select Player
2. See outstanding payable
3. Select reimbursement
4. Confirm payment
5. Record payment date
6. Mark payable as Paid

### Example

Akshay has:

**₹2,520 outstanding**

Administrator reimburses him.

Result:

- Payable: ₹0
- account: −₹2,520
- Reimbursement History: ₹2,520

---

# 25. Multiple Players Personally Paying Expenses

Different players can personally pay for different team expenses.

### Example

| Expense | Paid By | Amount | Team Owes |
|---|---|---:|---:|
| Balls | Akshay | ₹470 | Akshay ₹470 |
| Gloves | Rahul | ₹1,200 | Rahul ₹1,200 |
| Stumps | Amit | ₹850 | Amit ₹850 |

Total Team Payable:

**₹2,520**

But each player's payable remains independently traceable.

---

# 26. Financial Dashboard

The dashboard should show the team's complete financial position.

### Primary Metrics

- Starting Balance
- Total Collections
- Total Cash Expenses
- Additional Income
- Current account
- Total Due from Players
- Total Due to Players
- Total Outstanding
- Surplus

### Dashboard Summary

Example:

| Metric | Amount |
|---|---:|
| Starting Balance | ₹10,000 |
| Cash Collections | ₹3,882 |
| Cash Expenses | ₹4,970 |
| Additional Income / Surplus | ₹4 |
| Current account | ₹8,912 |
| Players Owe Team | ₹1,088 |
| Team Owes Players | ₹0 |

**Important:** Match Surplus is already part of the underlying cash collection. It must not be added to the account again.

The most important visual summary should clearly communicate:

> **Cash Available:** ₹8,912  
> **Players Owe Team:** ₹1,088  
> **Team Owes Players:** ₹0  
> **Additional Income / Surplus:** ₹4

---

# 27. account Calculation

The account represents **actual team cash available**.

### Fundamental Formula

**Current account = Starting Balance + All Actual Cash Inflows − All Actual Cash Outflows**

### Actual Cash Inflows

Examples:

- Match fee collections
- Player expense recoveries
- Ad Hoc Income
- Other legitimate cash receipts

### Actual Cash Outflows

Examples:

- Match expenses paid from account
- Team expenses paid from account
- Player reimbursements

### Important Accounting Rule

A financial amount must affect account exactly once.

For example:

If:

- Match fee obligations = ₹5,000
- Actual collection = ₹5,004

then:

- account increases by ₹5,004
- ₹5,000 is classified as settlement of player fee obligations
- ₹4 is classified as Match Surplus

The ₹4 is **not added separately** to account.

### Additional Income

Additional Income should distinguish between:

1. **Independent cash income**, such as sponsorship or contribution.
2. **Match Surplus**, which is a classification of excess within an existing match collection.

Independent income creates a new cash inflow.

Match Surplus does not create a second cash inflow.

### Player-Paid Team Expenses

If a player pays a team expense personally:

- Team expense is recorded
- Player payable is created
- account does not change

When the player is reimbursed:

- account decreases
- Player payable decreases

---

# 28. Complete End-to-End Example

This should be treated as the primary test scenario for the application.

## Step 1 — Starting Balance

Starting account:

**₹10,000**

---

## Step 2 — Match Created

Ground Fees:

₹4,000

Additional Amount:

₹500

Total Match Expense:

**₹4,500**

10 players participate.

Player Fee:

**₹450**

10 × ₹450 = ₹4,500

---

## Step 3 — Match Expense Paid

Match expense is paid from Team account.

account:

₹10,000 − ₹4,500

**₹5,500**

---

## Step 4 — Players Pay Match Fees

8 players pay ₹450 each.

Collection:

**₹3,600**

account:

₹5,500 + ₹3,600

**₹9,100**

Outstanding Match Fees:

2 × ₹450

**₹900**

---

## Step 5 — Akshay Buys Balls

Akshay personally purchases balls:

**₹470**

No account movement.

Team Payable:

**₹470 to Akshay**

account remains:

**₹9,100**

---

## Step 6 — Balls Allocated to Players

5 players are responsible for the balls.

₹470 ÷ 5:

**₹94 each**

Total Player Receivable:

**₹470**

---

## Step 7 — Three Players Pay

3 × ₹94:

**₹282**

account:

₹9,100 + ₹282

**₹9,382**

Remaining Player Receivable:

₹470 − ₹282

**₹188**

---

## Step 8 — Akshay Is Reimbursed

Team pays Akshay:

**₹470**

account:

₹9,382 − ₹470

**₹8,912**

Akshay's payable:

**₹0**

---

## Final Position

| Metric | Amount |
|---|---:|
| Starting Balance | ₹10,000 |
| Match Expense | ₹4,500 |
| Match Collections | ₹3,600 |
| Team Expense — Balls | ₹470 |
| Player Expense Collections | ₹282 |
| Player Reimbursement | ₹470 |
| Additional Income | ₹0 |
| **Current account** | **₹8,912** |
| Match Fee Outstanding | ₹900 |
| Team Expense Receivable Outstanding | ₹188 |
| **Total Due from Players** | **₹1,088** |
| **Total Due to Players** | **₹0** |

---

# 29. Match Surplus Acceptance Test

This must be an explicit acceptance scenario.

### Scenario A — Exact Collection

Actual Match Expense:

**₹5,000**

12 players.

Player Fee:

**₹417**

Total Fee Obligations:

**₹5,004**

Actual Collection:

**₹5,004**

Expected:

| Metric | Amount |
|---|---:|
| Match Expense | ₹5,000 |
| Player Fee | ₹417 |
| Total Fee Obligations | ₹5,004 |
| Total Collected | ₹5,004 |
| Fees Settled | ₹5,004 |
| Match Surplus | ₹0 |
| Outstanding | ₹0 |

The ₹4 rounding difference is already included in the fee obligations.

---

### Scenario B — Under-Collection

Total Fee Obligations:

**₹5,004**

Actual Collection:

**₹5,000**

Expected:

| Metric | Amount |
|---|---:|
| Total Fee Obligations | ₹5,004 |
| Total Collected | ₹5,000 |
| Fees Settled | ₹5,000 |
| Match Surplus | ₹0 |
| Outstanding | ₹4 |

---

### Scenario C — Over-Collection

Total Fee Obligations:

**₹5,004**

Actual Collection:

**₹5,010**

Expected:

| Metric | Amount |
|---|---:|
| Total Fee Obligations | ₹5,004 |
| Total Collected | ₹5,010 |
| Fees Settled | ₹5,004 |
| Match Surplus | ₹6 |
| Outstanding | ₹0 |

The full ₹5,010 increases account.

The ₹6 surplus is a classification of that ₹5,010 and must not be added to account again.

---

### Additional Over-Collection Tests

| Fee Obligations | Actual Collection | Outstanding | Surplus |
|---:|---:|---:|---:|
| ₹5,000 | ₹5,002 | ₹0 | ₹2 |
| ₹5,000 | ₹5,005 | ₹0 | ₹5 |
| ₹5,000 | ₹4,998 | ₹2 | ₹0 |

---

# 30. Transaction Types

The application should support the following financial transactions.

| Transaction | Example | account Effect |
|---|---|---:|
| Starting Balance | ₹10,000 opening balance | +₹10,000 |
| Match Expense — account | Ground ₹4,000 | −₹4,000 |
| Match Fee Created | Player owes ₹450 | ₹0 |
| Match Fee Paid | Player pays ₹450 | +₹450 |
| Match Surplus | Excess match collection ₹4 | Included in collection |
| Ad Hoc Income | Team contribution ₹2,000 | +₹2,000 |
| Team Expense — account | Balls ₹470 | −₹470 |
| Team Expense — Player | Akshay pays ₹470 | ₹0 |
| Player Receivable Created | Player owes ₹94 | ₹0 |
| Player Receivable Paid | Player pays ₹94 | +₹94 |
| Player Reimbursement | Team pays Akshay ₹470 | −₹470 |

Every transaction should retain its date, amount, source, destination/party and status where applicable.

---

# 31. Match Detail Screen

Show:

- Match Date
- Status
- Participating Players
- Ground Fees
- Additional Amount
- Total Match Expense
- Player Fee
- Total Fee Obligations
- Total Collected
- Fees Settled
- Total Outstanding
- Match Surplus / Additional Income

For every participating player:

- Player Name
- Fee
- Status
- Payment Date
- Mark Paid action

The match should clearly distinguish:

**Expense**

from:

**Player Fee Obligations**

from:

**Actual Collections**

from:

**Match Surplus / Additional Income**

---

# 32. Team Expense Detail Screen

Show:

- Date
- Expense Category
- Amount
- Paid By
- Payment Source
- Team Payable
- Reimbursement Status
- Players Responsible
- Amount Recoverable
- Amount Recovered
- Amount Outstanding

Example:

**Cricket Balls — ₹470**

Paid By:

**Akshay**

Payment Source:

**Player**

Team Owes:

**₹470**

Reimbursement:

**Due**

Players Responsible:

**5**

Allocation:

**₹94 each**

Recovered:

**₹282**

Outstanding:

**₹188**

---

# 33. Reimbursement Screen

Provide a dedicated view of all outstanding player payables.

Example:

| Player | Outstanding | Action |
|---|---:|---|
| Akshay | ₹470 | Reimburse |
| Rahul | ₹1,200 | Reimburse |
| Amit | ₹850 | Reimburse |

Selecting Akshay shows:

**Outstanding: ₹470**

After reimbursement:

**Outstanding: ₹0**

account decreases by ₹470.

---

# 34. Outstanding / Receivables Screen

Show all money owed by players.

Example:

| Player | For | Amount | Status |
|---|---|---:|---|
| Rahul | Match Fee | ₹450 | Due |
| Amit | Match Fee | ₹450 | Due |
| Ravi | Cricket Balls | ₹94 | Due |

Filters:

- Player
- Match
- Expense
- Date
- Status

---

# 35. Player Summary

Example:

### Akshay

**Player Owes Team**

₹94

**Team Owes Player**

₹470

**Net Position**

Team owes Akshay:

**₹376**

The two underlying balances remain independently visible.

---

# 36. Financial Reports

Reports should support:

- Player-wise outstanding
- Player-wise ledger
- Match-wise collections
- Match-wise expenses
- Match-wise fee obligations
- Match-wise surplus
- Team expenses
- Expense category totals
- Player payables
- Player receivables
- Reimbursements
- Additional income
- Total collections
- Total expenses
- account balance
- Surplus

Filters:

- Date Range
- Player
- Match
- Payment Status
- Expense Category
- Income Type

---

# 37. Match Cancellation

Cancelled matches should not contribute to active financial totals.

If a match is cancelled before any payment:

- Its player fees become inactive
- Its expense does not count toward active financial totals
- Outstanding amounts are removed from active receivables
- Match surplus/income associated with the cancelled match is removed from active totals if it has not already been settled

Historical information must remain visible.

If payments already exist, cancellation must require confirmation and preserve the financial history.

The system must never silently erase financial transactions.

---

# 38. Editing Financial Records

Matches and expenses remain editable.

When an edit affects an existing financial transaction, the application must clearly show the financial impact before saving.

### Example

Original:

- Match Expense: ₹4,500
- 10 players
- Fee: ₹450

Change expense to:

**₹5,000**

New fee:

**₹500**

If nobody has paid, all outstanding fees can be recalculated.

If players have already paid ₹450, the system must not silently overwrite those payments.

The administrator must be warned and confirm the resulting financial adjustment.

Any existing surplus or additional income associated with the match must also be recalculated or explicitly adjusted where the underlying fee obligation changes.

---

# 39. Financial Integrity Rules

The following rules are mandatory:

1. Match expenses and team expenses are separate.
2. Match player fees are separate receivables.
3. Match fee obligations are calculated using whole-rupee ceiling.
4. Match fee obligations may differ from the actual match expense because of rounding.
5. Actual collections are separate from player fee obligations.
6. If actual match collections exceed total fee obligations, the excess becomes Match Surplus / Additional Income.
7. Match surplus does not create another player obligation.
8. Match surplus increases team income and account through the actual collection.
9. The rounding difference between actual match expense and rounded fee obligations is not automatically surplus.
10. Ad Hoc Income is separate from match expenses.
11. Match Additional Amount is an expense and must not be confused with Additional Income.
12. Team expenses paid by the account reduce account immediately.
13. Team expenses personally paid by players create player payables.
14. Personally paid team expenses do not reduce account until reimbursement.
15. Player reimbursements reduce account.
16. Player receivable payments increase account.
17. Player receivables and player payables are always separate.
18. A player can simultaneously owe the team and be owed money by the team.
19. No partial match-fee payments against an individual fee obligation.
20. No partial reimbursements.
21. Team expense allocations must sum exactly to the expense amount.
22. Team expense allocation uses selected-player order for distributing remainder rupees.
23. Historical transactions must remain traceable.
24. Cancelled matches must not inflate active financial totals.
25. Rounding and surplus information must be visible.
26. Financial edits affecting payments require confirmation.
27. No financial transaction should be silently deleted.
28. Every cash movement must have a clear source and destination.
29. The same cash movement must never be counted twice in account calculations.
30. Match Surplus must never be added to account separately when it is already included in the underlying actual collection.
31. Independent Additional Income must only be counted once as a cash inflow.
32. Dashboard, ledgers and reports must reconcile to the same underlying financial records.

---

# 40. UI / UX

The application should feel like a **premium sports management product**, not a generic accounting system.

### Visual Direction

- Glamorous
- Premium
- Modern
- Sports-focused
- Strong typography
- High-quality cards
- Data visualisation
- Smooth interactions
- Subtle animations
- Clear financial hierarchy

### Dashboard

Use visual cards for:

- account
- Collections
- Expenses
- Additional Income
- Players Owe
- Team Owes Players
- Surplus

Use charts where useful for:

- Collections over time
- Expenses over time
- Expense categories
- Outstanding amounts
- Additional income

---

# 41. Themes

Allow users to choose:

- Light
- Dark
- Cricket Green
- Midnight
- Maroon
- Royal Blue
- Monochrome
- Luxury / Gold

Theme selection should persist between sessions.

---

# 42. Responsive Design

The application must work across:

- Desktop
- Tablet
- Mobile

Mobile users must be able to perform the core workflows:

- View dashboard
- Create match
- Select players
- Record match payments
- Add team expenses
- Record player-paid expenses
- View player payables
- Reimburse players
- Record player receivable payments
- Record additional income
- View account
- View outstanding amounts

---

# 43. Navigation

Recommended primary navigation:

1. **Dashboard**
2. **Matches**
3. **Players**
4. **Team Expenses**
5. **Receivables**
6. **Payables**
7. **Reimbursements**
8. **Additional Income**
9. **Reports**
10. **Settings**

The interface should avoid unnecessary accounting terminology where simpler language works.

Use:

- **Players Owe**
- **Team Owes Players**
- **Paid**
- **Due**
- **account**
- **Collections**
- **Expenses**
- **Additional Income**
- **Surplus**

---

# 44. Single Source of Truth

The application should treat every financial event as a traceable transaction.

A transaction should always answer:

**What happened?**

**When did it happen?**

**How much was it?**

**Who paid?**

**Who received the money?**

**Who owes whom?**

**Has it been settled?**

**What happened to the Team account?**

The dashboard, player ledger, match screens, expense screens and reports should all derive their financial figures from the same underlying transaction records.

This prevents the same amount from being counted differently in different parts of the application.

---

# 45. Acceptance Test — Core Financial Flow

A completed implementation should pass this scenario:

1. Create team with ₹10,000 starting balance.
2. Create a ₹4,500 match for 10 players.
3. Confirm ₹450 fee per player.
4. Confirm total fee obligations are ₹4,500.
5. Pay match expense from account.
6. Confirm account becomes ₹5,500.
7. Record 8 player payments.
8. Confirm account becomes ₹9,100.
9. Confirm ₹900 match receivable remains.
10. Create ₹470 cricket-ball expense.
11. Mark Akshay as the personal payer.
12. Confirm account remains ₹9,100.
13. Confirm Team Owes Akshay ₹470.
14. Allocate the ₹470 expense to 5 players.
15. Confirm ₹94 receivable per player.
16. Record 3 player payments.
17. Confirm account becomes ₹9,382.
18. Confirm ₹188 remains receivable.
19. Reimburse Akshay ₹470.
20. Confirm account becomes ₹8,912.
21. Confirm Akshay's payable becomes ₹0.
22. Confirm total player receivables are ₹1,088.
23. Confirm total player payables are ₹0.
24. Confirm the complete transaction history remains visible.

---

# 46. Acceptance Test — Match Over-Collection

The implementation must also pass these scenarios.

### Scenario 1 — Exact Collection

1. Match fee obligations: ₹5,004.
2. Actual collections: ₹5,004.
3. Confirm fees settled: ₹5,004.
4. Confirm outstanding: ₹0.
5. Confirm surplus: ₹0.
6. Confirm account increases by ₹5,004.

### Scenario 2 — Under-Collection

1. Match fee obligations: ₹5,004.
2. Actual collections: ₹5,000.
3. Confirm fees settled: ₹5,000.
4. Confirm outstanding: ₹4.
5. Confirm surplus: ₹0.
6. Confirm account increases by ₹5,000.

### Scenario 3 — Over-Collection

1. Match fee obligations: ₹5,004.
2. Actual collections: ₹5,010.
3. Confirm fees settled: ₹5,004.
4. Confirm outstanding: ₹0.
5. Confirm surplus: ₹6.
6. Confirm account increases by ₹5,010.
7. Confirm the ₹6 surplus is not added to account a second time.

### Scenario 4 — Multiple Values

Also test:

- ₹5,002 collected against ₹5,000 obligations → ₹2 surplus
- ₹5,005 collected against ₹5,000 obligations → ₹5 surplus
- ₹4,998 collected against ₹5,000 obligations → ₹2 outstanding and ₹0 surplus

---

# 47. Future Expansion

The architecture should allow future addition of:

- Multiple teams
- Multiple administrators
- Player login
- Payment gateways
- UPI payment links
- Automated payment reminders
- WhatsApp notifications
- Expense receipts
- Export to Excel/CSV/PDF
- Annual financial summaries
- Team seasons
- Match statistics
- Cricket scoring integration

These features are **not required for the initial version**, but the architecture should not prevent them.