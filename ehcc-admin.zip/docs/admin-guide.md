# EHCC Expense Tracker — Admin User Guide

## Overview

The EHCC Expense Tracker is a financial ledger for cricket teams. It tracks income, expenses, transfers between accounts, player balances, and settlements (reimbursements and collections).

**Key concept:** Balances are always calculated from transactions — nothing is stored directly. This means there's a single source of truth.

---

## Getting Started

1. **Log in** with the admin password (set via `ADMIN_PASSWORD` environment variable)
2. **Create a team** in Settings → Teams. This automatically creates a team account.
3. **Add players** in the Players section. You can add one at a time or import from CSV.
4. **Start recording transactions** from the "Add transaction" page.

---

## Dashboard

The dashboard shows:
- **Income** — total money coming in
- **Expenses** — total money going out
- **Team account balance** — opening balance + income - expenses
- **Expected after pending** — projected balance after all pending settlements
- **Expenses by category** — bar chart breakdown
- **Outstanding balances** — who owes what
- **Recent transactions** — last 10 entries

---

## Recording Transactions

### Expense
1. Go to **Add transaction**
2. Select **Expense** type
3. Choose the date, category, and description
4. Select **who paid** (a player or the team account)
5. Select **who to charge** (multiple players/team)
6. Enter the amount
7. The system automatically splits the amount equally, rounding up to the nearest rounding step (default ₹5). The rounding difference becomes team surplus.

### Income
1. Select **Income** type
2. Choose category and amount
3. Optionally select which player contributed (or leave as "External")
4. Money lands in the team account

### Transfer
1. Select **Transfer** type
2. Choose which account pays and which receives
3. Enter amount and optional note

---

## Settlements

### Reimbursement
When a player pays for an expense (e.g., ground charges), the team owes them money.
- Go to the transaction → click **PAY** next to "Reimburse"
- This creates a transfer from the team account to the player
- The player's balance updates automatically

### Collection
When a player owes their share of an expense:
- Go to the transaction → click **Collect** next to the player's name
- This creates a transfer from the player to the team account

### Settle Net
When a player both owes money AND is owed money:
- Go to the player's page → click **Settle net**
- The system calculates the difference and creates ONE transfer
- All pending items for that player are marked settled together
- Undoing any item undoes the whole batch

---

## Player Management

- **Add player:** Players → Add player (name + optional mobile)
- **Import CSV:** Players → Import from CSV (columns: player_name, mob_no)
- **Edit player:** Players → click player → Edit
- **Archive player:** Players → click player → Archive (keeps history, hides from active lists)
- **Delete player:** Only available for players with NO transaction history

---

## Settings

### Teams
- Add, rename, archive/restore teams
- Set starting balance for each team account

### Categories
- Add, rename, archive/restore income and expense categories
- "Other" category always requires a description

### Themes
- 25 built-in themes with automatic WCAG AA contrast enforcement
- Click any theme to apply it

### Rounding Step
- Controls how expense shares are rounded (default: ₹5)
- Applies to new and edited transactions

### Data Reset
- Delete all transactions (or only those after a specific date)
- Requires typing "DELETE" to confirm
- Teams, players, categories, and audit log are preserved

### Full Backup
- Export all data as CSV or PDF
- PDF includes team summaries, player balances, and full transaction history

---

## Export

### Per Team
- Dashboard → **Export CSV** or **Export PDF**
- CSV: team × player matrix with all transactions
- PDF: full financial report

### Full Backup
- Settings → Full backup → **Export full CSV** or **Export full PDF**
- Includes all teams in one file

---

## Audit Log

Every action is recorded in the audit log (Settings → Audit log):
- Who performed the action
- What was done
- Which team/entity was affected
- Timestamp and details

The audit log is append-only and cannot be deleted.

---

## Tips

- **Void vs Delete:** Nothing is hard-deleted by normal use. Voiding a transaction reverses its settlements and marks it void.
- **Team scoping:** All transactions are team-specific. Switch teams using the team selector at the top.
- **Mobile:** Use the bottom navigation bar for quick access. The sidebar is available via the hamburger menu.
- **Keyboard:** Press Escape to close the sidebar on mobile.
