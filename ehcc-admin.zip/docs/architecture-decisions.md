# Architecture Decision Records

## ADR-001: Derived Balances (Never Stored)

**Status:** Accepted  
**Date:** 2026-09-01

### Context
Player and team account balances need to be always accurate and consistent with the transaction history.

### Decision
Balances are computed on-the-fly from active transactions using SQL aggregation. No balance columns are stored on any table.

### Consequences
- **Pros:** Single source of truth, no reconciliation needed, void/reversal is trivial
- **Cons:** Slightly more expensive queries (mitigated by proper indexing)

---

## ADR-002: Full-Only Settlements

**Status:** Accepted  
**Date:** 2026-09-01

### Context
Players may owe money to the team (their share of expenses) or the team may owe them (reimbursement for expenses they fronted).

### Decision
Settlements are always full — no partial payments. A settlement covers the entire pending amount in one transfer.

### Consequences
- **Pros:** Simpler logic, no partial payment tracking, easier to reason about
- **Cons:** Less flexible for real-world scenarios where partial payments are common

---

## ADR-003: Net Settlement Batches

**Status:** Accepted  
**Date:** 2026-09-01

### Context
A player may have multiple pending items — some they owe, some they are owed. Settling each individually is tedious.

### Decision
The "Settle net" feature calculates the difference and creates ONE transfer. All pending items are marked settled together with a shared `batch_id`. Undoing any item reverses the entire batch.

### Consequences
- **Pros:** One tap settles everything, atomic undo, no cash movement when amounts cancel out
- **Cons:** All-or-nothing — can't undo individual items within a batch

---

## ADR-004: No Frontend Build Step

**Status:** Accepted  
**Date:** 2026-09-01

### Context
The app is a server-rendered MVP with minimal client-side interactivity.

### Decision
Use vanilla HTML/CSS/JS with Jinja2 templating. No npm, no bundler, no TypeScript, no framework.

### Consequences
- **Pros:** Zero build tooling, instant startup, easy to deploy, no node_modules
- **Cons:** No type safety in JS, no component reuse beyond Jinja macros, CSS grows as one file

---

## ADR-005: Database-Level Constraint Enforcement

**Status:** Accepted  
**Date:** 2026-09-01

### Context
Critical business rules must not be bypassed by application bugs.

### Decision
Enforce rules at the database level:
- Partial unique index prevents duplicate active settlements
- Check constraints on status values
- Triggers enforce append-only audit log on both PostgreSQL and SQLite

### Consequences
- **Pros:** Rules hold even if application code has bugs, multi-app safe
- **Cons:** Harder to change rules (requires migration), dual-path for SQLite/PostgreSQL

---

## ADR-006: Shared Admin Password (No User Accounts)

**Status:** Accepted  
**Date:** 2026-09-01

### Context
The app is used by a single admin (or a small trusted group).

### Decision
Single shared password. Admins enter their name at login for the audit log. No per-user accounts.

### Consequences
- **Pros:** Simple, no user management, no password recovery
- **Cons:** No individual accountability, password sharing required for multiple admins

---

## ADR-007: Server-Side Team Scoping

**Status:** Accepted  
**Date:** 2026-09-01

### Context
Multiple teams share one database. Data must be isolated.

### Decision
All service-layer functions validate that accounts belong to the requested team. UI filters are a convenience, not a security boundary.

### Consequences
- **Pros:** Prevents cross-team data leaks even if UI has bugs
- **Cons:** Every service function must include team validation

---

## ADR-008: Exception Hierarchy with HTTP Status Codes

**Status:** Accepted  
**Date:** 2026-09-01

### Context
Different errors need different HTTP status codes and field-level display.

### Decision
```python
LedgerError(Exception)      # Base, HTTP 400, optional field attribute
├── NotFoundError           # HTTP 404
└── ConflictError           # HTTP 409
```

Each error carries an optional `field` attribute for form-level error display.

### Consequences
- **Pros:** Correct HTTP semantics, field-level form errors, easy to extend
- **Cons:** More exception classes to maintain

---

## ADR-009: CSS with @layer and Custom Properties

**Status:** Accepted  
**Date:** 2026-09-01

### Context
The CSS file was growing and becoming hard to maintain.

### Decision
Organize CSS using `@layer` (tokens, base, layout, components, mobile, utilities) with CSS custom properties for spacing, radii, and transitions.

### Consequences
- **Pros:** Clear organization, easy to override, modern CSS features, no preprocessor needed
- **Cons:** Slightly more verbose than minified CSS

---

## ADR-010: WeasyPrint for PDF Export

**Status:** Accepted  
**Date:** 2026-09-01

### Context
Admins need to export financial reports as PDF.

### Decision
Use WeasyPrint (HTML/CSS to PDF) with a dedicated print-friendly template.

### Consequences
- **Pros:** Beautiful PDF output, full CSS control, no JavaScript required
- **Cons:** Heavy dependency (~50MB with system libs), requires system libraries (pango, cairo)
