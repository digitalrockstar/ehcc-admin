# EHCC Expense Tracker — Developer Guide

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Python 3.12 |
| Web Framework | FastAPI |
| ORM | SQLAlchemy 2.0 |
| Migrations | Alembic |
| Database | PostgreSQL (prod) / SQLite (dev/test) |
| Templating | Jinja2 (server-rendered) |
| Frontend | Vanilla HTML/CSS/JS (no build step) |
| Testing | pytest + httpx |
| Deployment | Render |

---

## Project Structure

```
app/
├── main.py              # FastAPI app, middleware, exception handlers
├── config.py            # Environment-based configuration
├── db.py                # SQLAlchemy engine, session factory
├── models.py            # All ORM models (11 tables)
├── security.py          # Auth, CSRF, rate limiting
├── web.py               # Shared helpers: templating, team context, flash
├── formatting.py        # INR formatting, date formatting, IST conversion
├── themes.py            # 25 themes with WCAG AA contrast
├── routers/             # HTTP route handlers
│   ├── auth.py          # Login/logout
│   ├── dashboard.py     # Dashboard (home page)
│   ├── transactions.py  # CRUD for transactions, void, reimburse, collect
│   ├── players.py       # Player management, CSV import, settle-net
│   ├── settings.py      # Teams, categories, themes, rounding, data reset
│   └── export.py        # CSV and PDF export
├── services/            # Business logic layer
│   ├── ledger.py        # ALL financial rules
│   ├── masters.py       # Teams, players, categories, defaults
│   ├── views.py         # Display row builders
│   ├── audit.py         # Audit log writer
│   └── export.py        # CSV/PDF generation
├── templates/           # Jinja2 HTML templates
└── static/              # CSS, JS, fonts, favicon

alembic/                 # Database migrations
tests/                   # Test suite
docs/                    # Documentation
```

---

## Local Setup

### Prerequisites
- Python 3.12+
- PostgreSQL (optional — SQLite works for development)

### Steps

```bash
# 1. Clone and enter the repository
git clone <repo-url>
cd ehcc-admin

# 2. Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements-dev.txt

# 4. Configure environment
cp .env.example .env
# Edit .env:
#   ADMIN_PASSWORD=your-secure-password
#   SECRET_KEY=any-long-random-string
#   DATABASE_URL=sqlite:///./ehcc.db  (or PostgreSQL URL)

# 5. Run migrations
alembic upgrade head

# 6. Start the dev server
uvicorn app.main:app --reload
```

The app is now running at `http://localhost:8000`.

---

## Running Tests

```bash
# All tests
pytest

# Specific test file
pytest tests/test_ledger.py

# With coverage
pytest --cov=app tests/
```

Tests use an in-memory SQLite database — no setup required.

---

## Database Migrations

```bash
# Create a new migration
alembic revision --autogenerate -m "description"

# Apply migrations
alembic upgrade head

# Rollback one migration
alembic downgrade -1
```

---

## Deployment (Render)

The app includes a `render.yaml` blueprint for one-click deployment:

1. Push to GitHub
2. Create a new Render Web Service from the repo
3. Render auto-detects `render.yaml` and configures:
   - Python 3.12.3 build
   - `alembic upgrade head` on start
   - Auto-generated `SECRET_KEY`
   - Health check at `/healthz`

### Environment Variables

| Variable | Required | Default | Purpose |
|---|---|---|---|
| `DATABASE_URL` | Yes | `sqlite:///./ehcc.db` | Database connection string |
| `ADMIN_PASSWORD` | Yes | (empty) | Shared admin password |
| `SECRET_KEY` | Prod only | dev fallback | Session cookie signing |
| `APP_ENV` | No | `development` | Set to `production` for secure cookies |
| `SHOW_MOBILE_TO_VIEWERS` | No | `0` | Set to `1` to show mobile numbers to viewers |

---

## Code Style

- **Python:** PEP 8, type hints, docstrings for public functions
- **Templates:** Jinja2 with macros for reusable components
- **CSS:** Organized with `@layer`, custom properties, BEM-like naming
- **JS:** Vanilla, no framework, deferred loading

---

## Key Patterns

### Exception Hierarchy
```python
LedgerError(Exception)      # Base, HTTP 400, optional field attribute
├── NotFoundError           # HTTP 404
└── ConflictError           # HTTP 409
```

### Team Scoping
All service-layer functions enforce team isolation. A transaction from team A cannot reference accounts from team B.

### Derived Balances
Player and team balances are never stored. They are computed from active transactions via SQL aggregation.

### Audit Log
Every mutating action writes to `audit_log`. The table is append-only, enforced by database triggers on both PostgreSQL and SQLite.
